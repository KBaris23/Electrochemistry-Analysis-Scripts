﻿You are helping me finish a paper (ACS-style main text plus Supporting Information) on automated Bayesian optimization (BO) of square-wave voltammetry (SWV) parameters for electrochemical aptamer-based sensors. Do not invent data. If something is not stated here, look it up in the files or tell me it is unknown.

## Read first
`C:\TEMP\BO\analysis_plan\STEP_BY_STEP.md` is the single source of truth (situation, app changes, exact folders, analysis parameters, which channels/settings/portions to show, step-by-step workflows). Re-check its claims against the files before relying on them.

## Where things are (Windows)
- Data and plans: `C:\TEMP\BO` (four paper datasets, `titration_only\<ds>` copies for SWV-mode titration analysis, `analysis_plan\`).
- Analysis app: `C:\Users\Asus\OneDrive\Desktop\Jun-Chau Lab\Chien Lab Scripts\Analysis Scripts\swv_app` (Streamlit, `streamlit run app.py`; README.md describes the modes). Key files: `app.py` (SWV/CV analysis UI), `bo_session_viewer.py` (BO Session mode, Figure Composer), `bo_headless.py` (BO analysis entry point), `core/analysis.py`.
- Helper files in `analysis_plan\`: `channel_ranking_all_datasets.csv` (per channel/method response, SNR, Kd, R2), `make_titration_only.py`, `render_template_examples.py` (headless render of the Composer templates).

## Datasets (all complete)
kana setup 5 `500um_planar_BO_try_again_20260918_112055` (main; BO, 200-point sweep, titration 20-5,120 uM); kana station 2 `500um_planar_kana_20260917_170330` (replicate/SI, noisier); amp0 `100um_amp0_high_conc_20260915_130213` (SI; titration 1-64 mM); vanco `vanco_first_try_20260826_132944` (SI; 0.2-51.2 uM). Kana chips are 500 um planar; amp0 (100 um) and vanco (350 um) chip ids contain `np` (probably nanoporous; the SI table currently calls vanco planar). Surface chemistry is not recorded anywhere.

## Key results (kana setup 5 is the best titration dataset)
Optimized signal-on channels 1, 3, 4, 5, 7, 8, 10: R2 0.90-1.00, +160 to +320%, SNR 63-118; signal-off good on 3, 5, 7, 10; channels 2, 6, 9 unusable. Channel 5: optimized ON (500 Hz / 0.04 V / 0.002 V) gives ~3x the manual response (0.068 vs 0.022 uA at 5,120 uM) and lower prediction error (1.81x vs 2.10x RMS fold error) but a WORSE LOD than manual (22.7 vs 8.96 uM); check LOD per channel before claiming an LOD improvement. amp0 and vanco only partly worked (amp0: signal-off on channels 10, 6, 4 where manual often fails detection; vanco: weak, manual about as good); reactivity/surface retention/burn-off are hypotheses with no test in the data (no non-target control, reversibility not checked).

## App changes already made (uncommitted; 290 tests pass; see STEP_BY_STEP.md section 2)
SWV "BO analysis match" (load a BO session's settings + BO acceptance windows); "Add to Composer" under every SWV/CV plot; Composer per-panel X/Y range limits; Composer text sizes made absolute and equal across panels (Plotly px/pt bug fixed); chronological SWV stack offsets capped, thinned and defaulted to one channel; journal canvases at true print size (ACS 2-col 7.0 in, 1-col 3.3 in) plus a "Journal style" option (open axes, thin lines, no panel titles, frameless legends, letters outside the axes, marks scaled to the canvas); five Composer presets using that style (Landscape, BO optimization main, BO compact SI, Titration main 7 panels, Titration SI grid). The composer's old 12 in canvases print 8 pt text at about 4.7 pt in a 7 in column, so use the ACS canvases for paper figures. Gotchas: choose the data folder before loading a BO config; do not refresh the browser between capturing plots and composing; capture all Metrics-view plots before visiting Overlays; scope BO figures to one Channel group in the BO sidebar. The built-in preset "Hyperparameter Sweep" is the landscape layout.

## What I still need
Make the figures manually following STEP_BY_STEP.md; produce the missing simulation figures (BO vs random search, starting-point influence) with the app's Simulation tab; fill the SI blanks (exploration 0.7, GP falloff 0.2, initial budget 0). Ask me for anything missing, then help with the next unfinished step.

