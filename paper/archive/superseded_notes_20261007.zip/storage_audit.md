# Computer Storage Audit

Audit date: 2026-10-04  
Last updated: 2026-10-05  
Mode: read-only investigation; no files, applications, repositories, or settings were removed or changed during the audit.

> Cleanup/correction update (2026-10-05): At the user's request, the local `C:\TEMP\BO\500um_planar_BO_try_again_20260918_112055` extraction and its matching 704,122,087-byte ZIP were permanently deleted. Together they occupied approximately 2.52 GB. Later log review established that the paper set contains two distinct kana sessions—not one replacement session—plus one amp0 and one vancomycin session. Both kana archives must be retrieved from Tailscale. The original audit itself was read-only; the deletion was an explicit follow-up action.

> Important: C: free space fluctuated from 21.95 GB initially, down to 14.2 GB during the audit, and ended at 18.2 GB. The commands were read-only, but reading/hash-verifying OneDrive content can cause Files On-Demand hydration. Normal Windows/application activity may also have contributed.

## 1. Storage overview

| Drive | Capacity | Used | Free |
|---|---:|---:|---:|
| C: | 458.21 GB | 440.00 GB | 18.20 GB (4%) |
| Z: Tailscale share | 953.20 GB | 310.46 GB | 642.74 GB (67.4%) |

Largest local consumers:

| Location | Size |
|---|---:|
| `C:\Users\Asus\AppData` | 99.08 GB |
| `C:\Program Files` | 81.45 GB |
| `C:\Windows` | 59.63 GB |
| `C:\ProgramData` | 26.71 GB |
| `C:\Users\Asus\Downloads` | 24.52 GB |
| `C:\Program Files (x86)` | 21.22 GB |
| Visible OneDrive research/course trees | approximately 68+ GB |
| `C:\hiberfil.sys` | 6.17 GB |
| `C:\pagefile.sys` | 5.75 GB |

Folder sizes are logical file-size totals. Windows hard links, sparse files, compression, access-denied folders, and OneDrive state can make them differ from physical allocation.

## 2. AppData breakdown

| Location | Size | Notes |
|---|---:|---|
| `AppData\Local` | 87.90 GB | Main local consumer |
| `AppData\Roaming` | 10.70 GB | Application profiles/state |
| `AppData\LocalLow` | 0.47 GB | Small |
| `Local\Packages` | 26.11 GB | Store applications and app state |
| `Local\Microsoft` | 11.78 GB | Edge, Office, OneDrive, Windows |
| `Local\Programs` | 8.88 GB | User-installed applications |
| `Local\Autodesk` | 8.84 GB | Mostly `webdeploy` |
| `Local\Docker` | 7.25 GB | Mostly WSL/container disk |
| `Local\pip` | 4.46 GB | Package cache |
| `Roaming\Code` | 4.36 GB | VS Code data/cache |
| `Local\Temp` | 3.71 GB | Temporary data; one folder is 2.63 GB |
| `Local\Unity` | 2.75 GB | Almost entirely an old cache |
| `Local\Google` | 2.39 GB | Browser data/cache |

Notable subfolders:

- `Local\Packages\Claude_pzs8sxrjxfjjc`: 9.41 GB. Inspect from the application; do not manually remove unknown app state.
- `Local\Autodesk\webdeploy`: 8.56 GB, last major tree date 2024. Likely deployment/update material; use Autodesk-supported cleanup.
- `Local\Microsoft\Edge`: 7.42 GB. Contains browser profile/cache; do not delete the whole tree.
- `Local\Docker\wsl`: 7.23 GB. Review Docker images, containers and volumes before cleanup.
- `Local\Packages\Microsoft.SkypeApp...`: 6.67 GB. Uninstall Skype if genuinely unused.
- `Local\pip\cache`: 4.46 GB. Strong cache-cleaning candidate.
- `Local\Temp`: 3.71 GB. Review after closing applications.
- `Local\Unity\cache`: 2.74 GB, dating to 2022.
- `Roaming\Code\WebStorage`: 2.04 GB. May contain extension/workspace state.
- `Roaming\Code\CachedExtensionVSIXs`: 1.33 GB. Strong cache candidate.
- `Local\CrashDumps`: 0.197 GB.

## 3. Highest-confidence cleanup opportunities

These are recommendations only. Use each application's supported cleanup/uninstall path when available.

| Candidate | Size/reclaim estimate | Confidence | Suggested manual action |
|---|---:|---|---|
| McAfee `.etl` diagnostic logs | 16.57 GB | Very high | Use McAfee log/support cleanup or uninstall McAfee if unwanted. Do not delete while services run. |
| Autodesk `webdeploy` | 8.56 GB | High | Verify Fusion, then use Autodesk installer/cache cleanup. |
| Two old Ubuntu ISOs | 7.36 GB | High | Remove if no offline installer is needed. |
| Unity 2021.3.4f1 | 7.23 GB | High if unused | Uninstall through Unity Hub. |
| Conda package cache | 4.59 GB | Very high | Use `conda clean` manually. |
| pip cache | 4.46 GB | Very high | Clear through pip after checking offline needs. |
| `%LOCALAPPDATA%\Temp` | 3.71 GB | High | Review after closing apps. |
| Unity cache | 2.74 GB | Very high | Clear through Unity/Hub. |
| Exact duplicate HDF5 | 1.919 GB | Certain | Keep the copy referenced by scripts. |
| VS Code cached VSIX files | 1.33 GB | Very high | Clear after closing VS Code. |
| Old Downloads installers | about 1.66 GB | High | Remove if redownloadable. |
| Duplicate Downloads MP3 | 0.395 GB | Certain | Keep one copy. |
| `C:\adobeTemp` | 0.313 GB | High | Review after closing Adobe apps. |
| Recycle Bin | 0.12 GB | High | Empty manually when ready. |

A realistic initial recovery is approximately 30-45 GB without touching unique research data. Unused applications and research intermediates could increase this substantially.

## 4. Verified exact duplicates and archive overlaps

Approximately 5.8-6 GB of overlap was directly verified through SHA-256 or complete archive-content comparison.

### Deleted Jun-Chau BO snapshot and required replacement

- Deleted on 2026-10-05: `C:\TEMP\BO\500um_planar_BO_try_again_20260918_112055` (57,604 files, 1.861 GB).
- Also deleted: `...\Analysis Scripts\Data\500um_planar_BO_try_again_20260918_112055.zip` (704,122,087 bytes, previously reported as approximately 0.656 GB).
- Before deletion, every extracted file was verified against that ZIP by SHA-256. The two deleted items were duplicate representations of the same earlier snapshot.
- The deleted snapshot was **not** the latest complete setup-5 try-again session: its separate `parameter_sweep_20260921_110003` had started and continued beyond the older snapshot.
- Retrieve the latest/largest `500um_planar_BO_try_again_20260918_112055.zip` from `el infanto(setup 5)`. Successful upload paths were logged on both `desktop-s31irpl` and `desktop-ngl9j66`.
- Independently retrieve the other kana session, `500um_planar_kana_20260917_170330.zip`, from `\\100.94.40.35\Automation Data Drive\young_nephew`. It should contain `500um_planar_kana_20260917_170349` and `500um_planar_kana_param_sweep_20260921_111611`.
- These are distinct concurrent sessions on different setups. The final paper set is four folders/archives: two kana, one amp0 and one vancomycin.
- All known Tailscale endpoints and the mapped `Z:` drive were unavailable during the 2026-10-05 recheck, so current remote sizes remain unverified.
- The similarly named partial OneDrive folder is only about 30 MB and is not a substitute for the full Tailscale session.

### Duplicate HDF5

- `C:\Users\Asus\Downloads\gamma_angle_position_5deg_xy.h5`
- `C:\Users\Asus\.keras\datasets\gamma_angle_position_5deg_xy.h5`
- Both are 1.919 GB and have identical SHA-256: `B6E9A32CD6F8584E9E52D98F36B188232B5F66FB43E8810429BAFA285B84D0DC`.

### Kaggle cats-and-dogs archive/extraction

- ZIP: `Downloads\kagglecatsanddogs_5340.zip`, 0.768 GB.
- Extracted: `anaconda3\PetImages`, 0.807 GB.
- All 25,001 extracted files exactly match archive entries; the archive has two additional files.

### Downloads duplicate media

- `01-Seckin_Hatkaoglu.mp3` and `(1)` copy: exact, 0.395 GB reclaimable.
- Several duplicate WhatsApp/VID videos were confirmed, roughly another 0.05 GB.
- Two copies of `lecture1_2023_winter...pdf` are exact, 11.63 MB.

### Jun-Chau titration archives

Seven ZIP/folder pairs were compared file-by-file with SHA-256. Every file matched:

- `kana_trithiol_planar_033126.zip` / `titration rerun_20260331_205043`
- `kana_trithiol_nanoporous_040126.zip` / `kana_10_step_titration_final_20260401_190857`
- `kana_trithiol_nanoporous_040326.zip` / `2ndTest_same_chip_rerun_20260403_173324`
- `kana_trithiol_nanoporous_040626.zip` / `Titration_In_Box rerun_20260406_174300`
- `amp0_trithiol_planar_043026.zip` / `amp0 ten step, justine s chip_20260430_155226`
- `amp0_singlethiol_planar_050726.zip` / `rerun_20260507_163453`
- `amp0_singlethiol_planar_051526.zip` / `test_20260515_160555`

ZIPs consume about 0.094 GB; extracted folders consume about 0.341 GB. They are legitimate compact backups, but only one representation is required for content preservation.

### Other verified overlap

- `archive\emelt_SWV_Max.ipynb` and its `.ipynb_checkpoints` copy: exact, 65.2 MB.
- Multiple NumPy/SciPy/OpenBLAS/PyQt libraries are duplicated across Jun-Chau, Ti Lab and GitHub virtual environments. Over 0.3 GB of individual large-file duplication was confirmed; whole environment removal would save more.
- STM32 firmware repositories 1.28.0 and 1.28.1 repeat installers, media, libraries and PDFs. Over 0.3 GB of individual exact duplicates was confirmed.
- Two Adobe Premiere preview `.cfa` files are exact duplicates, about 54.5 MB.

## 5. Downloads audit

`C:\Users\Asus\Downloads` uses 24.52 GB.

| Category/item | Size |
|---|---:|
| Three 2022 `.MOV` files | 8.54 GB |
| Two Ubuntu ISOs | 7.36 GB |
| HDF5 dataset | 1.919 GB, exact duplicate in `.keras` |
| ZIP archives | 1.74 GB |
| EXE installers | 1.41 GB |
| PDF files | 1.07 GB |
| MSI installer | 0.25 GB |
| MP3 files | 0.799 GB, including 0.395 GB exact duplicate |
| Current paper figure-material folder | 0.401 GB |

The three MOV files are large but personal/media content, so inspect before removal. Old ISOs and installers are lower risk if redownloadable.

## 6. Applications and developer tooling

### Installed application trees

| Application/tree | Size | Assessment |
|---|---:|---|
| MATLAB R2026a | 23.58 GB | Likely active; retain if used. |
| MATLAB Runtime R2022b | 1.66 GB | Review against SNUPI needs. |
| Adobe applications | 15.87 GB | Premiere, Photoshop, Media Encoder, Illustrator, Acrobat. |
| Unity 2021.3.4f1 | 7.23 GB | Installed in 2022; strong uninstall candidate if unused. |
| Visual Studio + Windows SDK trees | roughly 9 GB | SDK 16299 and 19041 coexist. |
| KiCad 9 | 5.68 GB | Retain if active. |
| Altium program/shared data | 6.85 GB | Last major program-data dates to 2024. |
| IntelliJ IDEA 2023.3.2 | 2.38 GB | Review if unused. |
| STM32CubeIDE | 2.71 GB plus `C:\ST` | Review embedded-work requirements. |
| Docker Desktop | 3.32 GB program + 7.23 GB WSL data | Inspect images/volumes. |
| Ubuntu WSL application data | 2.76 GB | Retain if used. |

Reported installed-product sizes also showed Premiere Pro 9.86 GB, Altium 6.04 GB, Fusion 5.53 GB, Photoshop 3.44 GB, Media Encoder 3.30 GB, Illustrator 3.06 GB, Acrobat 2.54 GB, and two Windows SDK generations around 2 GB each. Registry estimates differ from directory totals.

### McAfee

- `C:\ProgramData\McAfee`: 16.97 GB.
- `wps\log`: 16.57 GB in only 190 `.etl` trace logs.
- Many individual logs are approximately 129 MB.
- This is the largest low-research-risk opportunity, but use McAfee's supported cleanup/removal path.

### Python/Conda/editor tooling

- Anaconda: 11.47 GB.
  - `pkgs`: 4.59 GB package cache.
  - Base `Lib`: 4.39 GB.
  - `Library`: 1.57 GB.
  - `PetImages`: 0.807 GB archive duplicate.
  - No substantial named Conda environments were found.
- VS Code extensions: 4.84 GB.
- VS Code roaming data: 4.36 GB.
  - WebStorage: 2.04 GB.
  - Cached VSIX installers: 1.33 GB.
- pip cache: 4.46 GB.
- Rust toolchain: 1.13 GB.
- `C:\venvs\ml_beta`: 0.915 GB.
- Codex data: 1.26 GB, including 0.48 GB sessions and an active logs database around 0.17 GB. Do not remove active databases while Codex is running.

## 7. Research audit: Jun-Chau Chien lab

Total local OneDrive tree: 6.23 GB, excluding `C:\TEMP` and Z: sessions.

| Component | Size | Classification |
|---|---:|---|
| `Chien Lab Scripts` | 5.61 GB | Mixed data/code/environments |
| `Analysis Scripts\Data` | 2.48 GB | Experimental data; retain |
| `Analysis Scripts\swv_app` | 0.875 GB | 0.812 GB is virtual environments |
| `ML_beta` | 0.92 GB | 0.918 GB virtual environment |
| `manual_setup_matlab` | 0.32 GB | Almost entirely virtual environment |
| `experiment_compare_app` | 0.353 GB | Almost entirely virtual environment |
| Misc/safety presentations | 0.547 GB | Review, but potentially important |

Findings:

- At least 2.75 GB inside the research tree is copied Python virtual environments.
- Requirements files exist for several projects, making those environments regenerable.
- Raw SWV/PSTrace CSV data should be retained; CSV files account for about 1.32 GB.
- The earlier 656 MiB BO ZIP and its 1.861 GB extraction were deleted on 2026-10-05. No complete local copy remains; retrieve the latest/largest setup-5 try-again archive and the separate station-2 planar-kana archive from Tailscale.
- Seven successful-titration ZIPs duplicate extracted experiment folders exactly.
- The active `swv_app` source, tests and Git history are small compared with its environments.

Original estimated reclaimable space: 3-5 GB at low/moderate risk, principally virtual environments, the now-deleted temp extraction, checkpoints and duplicate archive/extracted representations.

Retain raw experiment folders, complete BO archives, logs, metadata, source code, requirements, final paper figures and manuscript assets.

## 8. Research audit: Caltech COILab

Total: 22.11 GB.

| Component | Size |
|---|---:|
| `20260617_TRPWM_mfiles_Baris` | 21.93 GB |
| `preprocesssing\outputs` | 12.82 GB |
| Separate root `outputs` | 2.05 GB |
| `Data` | 5.22 GB |
| Alignment code/datasets | 1.35 GB |

Type distribution:

- MATLAB `.mat`: 16.63 GB.
- Acquisition/export `.txt`: 5.16 GB.
- Figures, code and documents are comparatively small.

Strong generated-output review candidates:

- `trpwm_mw5_tgc_closed_ridge_slide_outputs`: 2.25 GB.
- `debugging tgc`: 1.34 GB.
- Working and failed TGC preprocessing outputs: 2.31 GB combined.
- `mesh_pwm_validation`: 1.03 GB.
- Five preprocessing benchmark/sweep folders: roughly 2.64 GB combined.
- Multiple smoke/debug/validation trees.

Two similarly named `experimental_preprocessing` folders, each about 0.372 GB, are not duplicates. Full SHA-256 comparison found no common file hashes.

Retain acquisition `.txt` files, source/Git history, selected validated reconstructions, final figures and documentation of failed runs until scientific review is complete.

Potential recovery:

- Moderate review: 8-12 GB of regenerated benchmarks, debugging runs, parameter variations and intermediate reconstructions.
- Aggressive: approximately 14 GB after confirming figure provenance.
- Raw `Data`, including `failed tgc`, remains high risk because the files are unique acquisition records.

## 9. Research audit: Ti Lab / DNA origami

Total: 5.27 GB.

| Component | Size | Assessment |
|---|---:|---|
| Bundled MATLAB Runtime under SNUPI | 4.05 GB | Reinstallable dependency |
| `barisnano\.venv` | 0.436 GB | Regenerable |
| Autobreak/pyOrigamiBreak tree | 0.439 GB | Almost entirely dependencies/environment |
| Designs, papers, presentations, CAD | under 0.35 GB combined | Retain/review carefully |

This tree is dominated by runtimes rather than AFM/raw microscopy data. No large unique AFM collection was found.

Potential recovery: 4.5-4.9 GB if SNUPI can use the installed MATLAB Runtime or be reinstalled later and Python environments are reproducible.

## 10. Other OneDrive areas

- High School: 15.43 GB.
- Misc Scripts: 6.62 GB.
- Fall 2026 coursework: 6.13 GB.
- GitHub repositories: 1.63 GB.
- Transfers: 1.08 GB.

These warrant manual review but were not classified as disposable based solely on age.

## 11. Risk classification

### Low risk after quick verification

- McAfee `.etl` logs through supported cleanup.
- pip and Conda package caches.
- Unity cache.
- AppData Temp remnants.
- VS Code cached VSIX installers.
- One exact HDF5 copy.
- Duplicate Downloads media/PDF copies.
- Old ISO and application installers.
- Exact notebook checkpoints.

### Medium risk

- Python virtual environments after preserving requirements/lock files.
- Ti Lab bundled MATLAB Runtime.
- Autodesk deployment files.
- Docker/WSL images and volumes.
- Old Visual Studio/Windows SDK versions.
- Old Unity, IntelliJ, Altium or Adobe applications.
- Caltech benchmark/debug/output trees.
- Archive-versus-extracted research representations.
- Old course and high-school material.

### High risk / retain

- Unique raw acquisition data.
- Jun-Chau SWV/PSTrace folders and complete BO archives.
- Caltech acquisition text files and raw `Data`.
- Optimizer JSON, session logs and metadata.
- Final figures, manuscripts and submission packages.
- Source code, requirements, Git history and analysis configuration.
- The selected paper datasets until verified backups exist.

## 12. Recoverable-space estimates

- Very conservative: 25-35 GB.
- Normal cache/installer/ISO cleanup: 40-65 GB.
- Moderate application and environment cleanup: 65-100 GB.
- Aggressive cleanup including unused applications and regenerable Caltech outputs: 100-140+ GB.

MATLAB, active Adobe tools, active Docker data, raw research data and final paper assets are excluded from the conservative estimate.

## 13. Recommended manual review order

1. Address McAfee's 16.57 GB trace-log problem.
2. Clear pip, Conda, Unity and VS Code installer caches using supported tools.
3. Remove old Ubuntu ISOs and obsolete installers if unnecessary.
4. Decide which identical HDF5 path your scripts use.
5. Reconnect Tailscale and retrieve both kana archives: the latest/largest `500um_planar_BO_try_again_20260918_112055.zip` from setup 5 and `500um_planar_kana_20260917_170330.zip` from station 2.
6. Retrieve and verify the amp0 and vancomycin archives described in `bo_paper_data_audit.md`, giving four paper datasets total.
7. Uninstall unused Unity, old Visual Studio/SDK components or IntelliJ.
8. Rebuild/remove redundant research virtual environments.
9. Review Caltech generated outputs while figure-generation scripts are available.
10. Review Docker/WSL workloads.
11. Review High School, coursework, Transfers and Misc Scripts last.
