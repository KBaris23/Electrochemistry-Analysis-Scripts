﻿# BO paper: situation, settings and step-by-step (updated 2026-10-07)

Everything lives in `C:\TEMP\BO`. App: `C:\Users\Asus\OneDrive\Desktop\Jun-Chau Lab\Chien Lab Scripts\Analysis Scripts\swv_app` (`streamlit run app.py`).
To give this to another LLM, use `AI_HANDOFF_PROMPT.md` in this folder (it points back here).

---

## 1. Where things stand

| Dataset | Complete? | Role | Quality (app analysis with the BO session's own settings) |
|---|---|---|---|
| kana setup 5, `500um_planar_BO_try_again_20260918_112055` | yes: BO, 200-pt sweep, 6,000 titration scans | **main paper** | best. Optimized signal-on on channels 1, 3, 4, 5, 7, 8, 10: R2 0.90-1.00, +160 to +320%, SNR 63-118. Signal-off good on 3, 5, 7, 10. Channels 2, 6, 9 unusable (9 is dead). |
| kana station 2, `500um_planar_kana_20260917_170330` | yes | replicate / SI | noisier (SNR 2-8, most R2 < 0.6); best ch10 ON (R2 0.92). Its method files autorange from 14.75 uA (others 59 nA): likely cause, unconfirmed. |
| amp0, `100um_amp0_high_conc_20260915_130213` | yes, no sweep | SI | optimized signal-off responds on ch10, 6, 4 (-50 to -90%); manual often fails peak detection (up to 91% of scans). No clean saturation to 64 mM. |
| vanco, `vanco_first_try_20260826_132944` | yes, no sweep | SI | weak (7-26%) but real on ch2, 6 (signal-off); manual ch7/8 as good as optimized. Kd pins at the 1 uM lower bound. Best vanco run on the share. |

**One result to be careful with (kana setup 5, channel 5, from the app's Langmuir plot):** optimized signal-on gives about 3x the response of manual (0.068 vs 0.022 uA at 5,120 uM) and a lower prediction error (RMS fold error 1.81x vs 2.10x manual), but its **LOD (22.7 uM) is worse than manual's (8.96 uM)**; signal-off LOD is 75.2 uM. Check the Langmuir fit summary table for every channel before writing "improved LOD" in the paper.

What is wrong / missing:
- Surface chemistry (thiol type, MCH, aptamer concentration) is not recorded in any folder (notes fields are empty): take it from the lab notebook.
- Chip ids: kana `500_r_3_15` / `planar` (500 um planar), amp0 `100_r_np_39_15`, vanco `350_r_np_45_15` (`np` is probably nanoporous, which conflicts with the SI table calling vanco planar; the meaning of the tokens is my inference).
- Simulation figures (BO vs random search, starting-point influence, hyperparameter 2D/3D heatmaps) need simulation sessions that are not in these folders. The Composer already has the "Hyperparameter 2D heatmap / 3D heatmap / parallel coordinates" sources; they appear only for sessions saved by the app's Simulation tab.

Other vancomycin runs on the Tailscale share were checked and are worse or empty (`vanco_pbs_20260831`: poor fits; `vanco_drift_test_20260828`: only 3 doses, no clear response; `autotitration_350um_netz`, `vanco_first_try_20260825`: unfinished/empty). `Z:\unc(master)\vanco_500um_planar_20260908_113415.zip` is a planar vanco run whose titration signal is gone (80-94% of scans fail peak detection); it was extracted (no zip kept) to `C:\TEMP\BO\vanco_500um_planar_20260908_113415` and is not part of the paper set: delete it if unwanted.

---

## 2. What I changed in the app (uncommitted; 290 tests pass)

1. **SWV sidebar -> Peak / Baseline -> "BO analysis match"**: paste an experiment folder, click **Load analysis settings from BO config**; optional **Apply BO acceptance windows** (peak/minima voltage windows). Without the windows SWV mode accepts scans the BO analysis rejects (amp0 92% vs 72% accepted). With it, SWV mode reproduced my BO-settings run exactly.
2. **"Add to Composer" under every SWV/CV plot** (sends the exact plot, with its plot settings, to the Figure Composer in BO Session mode).
3. **Figure Composer, captured plots: "Limit X range / Limit Y range"** per panel (pick a window of measurements, a voltage window, a concentration window).
4. **Figure Composer text is now absolute and equal across panels.** One "Plot text" value (default 8 pt) now prints the same size on every panel: titles 1.1x, labels 1.0x, ticks 0.9x, legends/annotations 0.85x. Before, Matplotlib panels scaled their own original sizes and Plotly panels (parallel coordinates, 3D) were sized in pixels at print resolution, so they came out at roughly a third of the size. Saved presets that compensated with large "Plot text" values on Plotly panels will now look too big: reset them to the same value as the other panels.
5. **Chronological SWV stack is readable again.** Offsets are capped so the whole stack spans about 2 voltage ranges (stacks up to ~60 traces are unchanged), and the default is one channel. Before, hundreds of traces spread over many plot widths and collapsed to a diagonal line.
6. **Journal canvases and "Journal style"** (Composer controls). New canvases at true print size: `ACS 2-col (7.0 x 5.25 in)`, `ACS 2-col tall (7.0 x 8.5 in)`, `ACS 1-col (3.3 x 3.0 in)`. The old 4:3 canvas is 12 in wide, so 8 pt text there printed at about 4.7 pt once shrunk to a 7 in column. The **Journal style** checkbox gives open axes (no top/right frame), thin lines, no per-panel titles, frameless legends (short legends move above the axes) and bold panel letters outside the top-left corner of each panel; it also scales line widths and marker sizes of the Matplotlib panels to the canvas, and removes Plotly panel titles. Plotly dots and lines are scaled to the panel width, 3D tick/title fonts are compensated (Plotly draws them at a different size than 2D text), and the chronological stack thins itself to at most 60 traces (default "Max traces").
7. **BO panels now show one optimizer.** A channel group holds a maximize and a minimize optimizer; mixing them made the Q trace zig-zag and doubled the legends. The Composer has an **Optimizer shown in BO panels** selector (Both / maximize / minimize; the templates use maximize). Parallel coordinates and the 3D tensor are coloured by **Paired Q**; axis titles carry units (Frequency (Hz), Amplitude (V), Step size (V)); one-entry legends are dropped.
8. **"Clip extreme values" per panel** (trend panels, parallel coordinates, 3D/2D maps, heatmaps; on by default in the templates): limits the y-axis to the 1st-99th percentile (colour range 2nd-98th) so a few spikes do not dominate. Points are not deleted, only the view is clipped. It is the BO counterpart of the SWV "Remove extreme titration outliers" switch.
9. **Presets** (Composer -> Load a preset or saved figure): `Landscape (3D + traces + 2D slices)`, `BO optimization (main)`, `BO compact (SI 2x2)`, `Titration main (7 panels)`, `Titration SI grid (9 panels)`. All use the 7.0 in canvas, Arial 7 pt, 9 pt letters, 600 DPI, Journal style on. Loading a titration preset assigns the captures made since the last preset load, in capture order, and trims the panel count to the number of captures. Edit the templates freely; they are only starting points.
10. The existing built-in preset "Hyperparameter Sweep" is the **landscape** layout (two 3D tensors, two trace overlays, six 2D slices), not a simulation layout.

### Which template for which data (and what is still weak)

| Template | Use it for | Do not use it for | Known weak points |
|---|---|---|---|
| `BO optimization (main)` | kana setup 5, sidebar Channel groups = Group 5 (or 3): the main-paper BO figure | SI datasets | Parallel coordinates and the 3D tensor show the same parameter space: keep one in the paper and move the other to the SI. Plotly panels are crowded at 7 pt (set to 6 pt). |
| `BO compact (SI 2x2)` | amp0 (group 10), vanco (group 2 or 6), kana station 2 (group 10) | the main figure | none beyond the above |
| `Landscape (3D + traces + 2D slices)` | the two kana sweeps only (setup 5 for the main figure, channels 3 and 5; station 2 for the SI) | amp0, vanco (no sweep) | Not re-rendered after the journal change: check it once. |
| `Titration main (7 panels)` | kana setup 5 channel 5 (channel 3 alternative); also single-channel SI figures for amp0 channel 10 and vanco channel 6 | station 2 (except channel 10) | Legends on the Langmuir/SNR panels are long (turn them off or keep one); consider dropping SNR (SI) and showing only optimized-ON vs manual overlays. Not re-rendered after the journal change: check it once. |
| `Titration SI grid (9 panels)` | one Langmuir fit per good channel: setup 5 (1, 3, 4, 5, 7, 8, 10), station 2 (10, 9, 4), amp0 (10, 6, 4), vanco (2, 6, manual 7) | a single-channel story | sort the panels by channel |

Not covered by any template: the simulation figures (BO vs random search, starting-point bias, hyperparameter heatmaps).

`render_template_examples.py` (this folder) drives the real app headlessly and renders the templates to `examples\`; it is slow (many full-app reruns) and was only a check.

Traps:
- In SWV mode choose the **data folder first, then** load the BO config (changing the folder later resets the crop).
- Do not refresh the browser between capturing plots and composing: captures live in the session.
- The Metrics view loses some widget state when you visit Overlays and come back (the Langmuir plot can disappear): capture all Metrics-view plots first, then the Overlays, and do not go back.
- BO figures mix every channel group unless you scope them: in BO Session mode set the sidebar **Channel groups** to one group (e.g. Group 5) before composing.

---

## 3. Datasets, sessions, analysis parameters

Titration-only folders (use in SWV mode; they contain `session_log.txt`, so vlines are **autodetected**; do not type vlines):

| Dataset | SWV-mode folder | Experiment folder for "BO config path" |
|---|---|---|
| kana setup 5 | `C:\TEMP\BO\titration_only\kana_try` | `C:\TEMP\BO\500um_planar_BO_try_again_20260918_112055\planar_BO_kana_20260918_112056` |
| kana station 2 | `C:\TEMP\BO\titration_only\kana_st2` | `C:\TEMP\BO\500um_planar_kana_20260917_170330\500um_planar_kana_20260917_170349` |
| amp0 | `C:\TEMP\BO\titration_only\amp0` | `C:\TEMP\BO\100um_amp0_high_conc_20260915_130213\amp0_100um_20260915_130234` |
| vanco | `C:\TEMP\BO\titration_only\vanco` | `C:\TEMP\BO\vanco_first_try_20260826_132944\vanco_try_1_20260826_132945` |

BO sessions (Analysis mode -> BO Session; paste the full session folder, i.e. the experiment folder plus `\bo_sessions\<id>`):

| Dataset | Session id |
|---|---|
| kana setup 5 BO / sweep | `bo_113013_8dd581` (under `planar_BO_kana_...`) / `bo_111904_a0d8ad` (under `parameter_sweep_20260921_110003`) |
| kana station 2 BO / sweep | `bo_171120_dc5dbc` / `bo_112206_86a834` (under `500um_planar_kana_param_sweep_20260921_111611`) |
| amp0 BO | `bo_145633_9f5760` |
| vanco BO | `bo_142117_84662a` |

Analysis parameters (all filled by the Load button; check them once):

| Sidebar control | kana setup 5 | kana station 2 | amp0 | vanco |
|---|---|---|---|---|
| Crop min / max (V) | -0.55 / 0.00 | **-0.45 / 0.10** | -0.55 / 0.00 | -0.55 / 0.00 |
| Min start voltage (V) | -0.6 | **-0.5** | -0.6 | -0.6 |
| Savitzky-Golay window / order | 15 / 2 | 15 / 2 | 15 / 2 | 15 / 2 |
| Minima search window (V) | 0.30 | 0.30 | 0.30 | 0.30 |
| Double baseline correction | on | on | on | on |
| Min peak height (uA) | 0.001 | 0.001 | 0.001 | 0.001 |
| Use prominent local minima | on | on | on | **off** |
| Compute skew / wavelet | off / off | off / off | off / off | off / off |
| Apply BO acceptance windows | on | on | on | on |
| Peak window (V) | -0.45 to -0.10 | -0.35 to 0.00 | -0.45 to -0.10 | -0.45 to -0.10 |
| Left minimum window (V) | -0.54 to -0.10 | -0.44 to 0.00 | same | same |
| Right minimum window (V) | -0.45 to -0.01 | -0.35 to 0.09 | same | same |
| Require prominent minima both sides | on | on | on | **off** |

Also set: Group plotted traces by = **SWV settings**. BO-run settings for the methods text (nothing to set in the app): exploration 0.7 per group, GP falloff 0.2, candidate pool 1000/100, n_initial 0, seed 42, Matern GP, paired-response objective (pairwise repeat-scan SNR); frequency 10-500 Hz, amplitude 10-200 mV, step 1-10 mV; 50 BO iterations per channel group; sweeps are 200 random "survey" iterations x 10 channels. Potentiostat: bandwidth 4k (kana setup 5) vs 8k; lowest autorange 59 nA, station 2 14.75 uA. Titration series: kana 20-5,120 uM (doubling; the lowest dose is measured twice, `20 uM_1` is the equilibration block), amp0 1,000-64,000 uM, vanco 0.2-51.2 uM; 10 repeats per block, 180 s equilibration.

---

## 4. What to show: channels, settings, portions of the curves

**kana setup 5 (main figure), channel 5** (both directions work and the manual method is clean):

| Method (as listed in the app) | Frequency / amplitude / step | Result |
|---|---|---|
| SWV Method 1, optimized signal-on | 500 Hz / 0.04 V / 0.002 V | +0.068 uA at 5,120 uM (about 3x manual); Kd ~410 uM; R2 0.99 |
| SWV Method 2, optimized signal-off | 138 Hz / 0.09 V / 0.003 V | -0.014 uA; R2 0.97 |
| SWV Method 3, manual | 200 Hz / 0.036 V / 0.002 V | +0.022 uA |

Alternative single-channel figures: channel 3 (500 Hz / 0.05 V / 1 mV on; 125 Hz / 0.07 V / 8 mV off), channel 7 (297 Hz / 0.04 V / 1 mV on), channel 10 (297 Hz / 0.04 V / 1 mV on). For the SI grid of Langmuir fits use channels 1, 3, 4, 5, 7, 8, 10 (optimized signal-on).

Portions to look at:
- **Time-course panel:** full series (scans 1-200 on the method-local axis, doses 20 to 5,120 uM). The first 20 uM block is the equilibration block; zoom the Composer X range to about 60-200 (doses of 40 uM and above) if the low-dose steps are crowded.
- **Voltammogram overlays:** the peak is at about -0.24 V. In the Composer set the **X range to -0.45 to -0.05 V** to hide the steep edge at -0.55 V (large on the signal-off method) and show the colour range from 1 to 200 (buffer to 5,120 uM). To contrast only the extremes, run the analysis view with Display subsection (Show only a smaller subsection of the analyzed results) on scan numbers 1-30 (initial buffer) and 571-600 (5,120 uM) per channel, and capture again.
- **Langmuir fit:** full 0-5,120 uM; show LOD but not ULOQ (ULOQ is an extrapolation here).
- **BO figure (BO Session mode, Channel groups = Group 5):** Q_run over all 50 iterations; peak height (uA), buffer vs target; chronological SWV stack for channel 5 (one channel, both phases); parallel coordinates and 3D tensor (amplitude / frequency / step) on the peak-height or Q metric. The overall best observation of this session is iteration 47 (297 Hz / 40 mV / 1 mV).
- **Landscape figure (sweep session `bo_111904_a0d8ad`, all groups):** channels 3 and 5, step slices 1, 4, 7 mV; for the two voltammogram insets pick the best and the worst Q iteration of the chosen channel from the History table (sort by Q).

SI datasets:
- **Station 2:** channels 10 (ON, R2 0.92), 9 (ON, R2 0.80), 4 (ON, R2 0.69); analysis settings differ (crop -0.45 to 0.10).
- **amp0:** channel 10 signal-off (R2 0.90, -53%), channel 6 signal-off (R2 0.70, -58%), channel 4 signal-off; show manual next to each because manual often fails detection; state that fits do not saturate up to 64 mM.
- **vanco:** channel 2 signal-off (R2 0.87, -22%), channel 6 signal-off (R2 0.91, -23%), manual channel 7 (R2 0.95). Run with prominent minima and require-local-minima **off**; state the aptamer burn-off caveat as a hypothesis.

---

## 5. Step by step (one figure at a time)

### 5.1 Titration main figure (7 panels)
1. Sidebar -> Analysis mode **SWV**. Paste the SWV-mode folder (section 3) in Data Folders.
2. Set "Group plotted traces by" = **SWV settings**.
3. Peak / Baseline -> **BO analysis match**: paste the experiment folder, **Load analysis settings from BO config**, confirm the green message and the values (section 3). Click **Run Analysis**.
4. Scan Annotations: the message "Autotitration detected" should appear and the vline box fills itself. Tick **Treat vline intervals as titration steps**, **Fit Langmuir-style curve to step plateaus**, optionally **Show LOD on plots**; **Titration baseline mode = Immediately preceding buffer**. In "Concentrations included in titration statistics" deselect `20 uM_1` if you treat it as equilibration. Click **Apply Display Controls**.
5. Set "Channels to plot" to `5`. View = **Metrics**; "Channels to combine" = the three Channel 5 entries; "Metrics to display" = peak current.
6. Click **Add to Composer** on, in this order: (A) the combined peak-current trace, (B) Channel 5 Langmuir fit, (C) SNR by concentration, (D) Predicted vs. Known. Then switch the View to **Overlays** and add (E) method 1, (F) method 2, (G) method 3 overlays of channel 5. Do not return to Metrics.
7. Analysis mode -> **BO Session**, open the kana setup 5 BO session. Figure Composer -> Load a preset -> **Titration main (7 panels)** -> Load preset.
8. In each panel's expander set the same "Plot text" (8), use "Limit X range" for windows (section 4), turn legends off where they cover data, then **Render figure** and download PNG/PDF/SVG.

### 5.2 SI titration grid
Same as 5.1 steps 1-4, then "Channels to plot" = `1,3,4,5,7,8,10`, Metrics view, **Add to Composer** on each channel's Langmuir plot, then BO Session mode -> preset **Titration SI grid (9 panels)**. Export the Langmuir fit summary CSV (Kd, LOD, R2) from the Export tab for the SI table. Repeat for station 2, amp0 and vanco with their own folders and settings.

### 5.3 BO figure
BO Session mode, open the session (section 3), sidebar **Channel groups = Group 5** (or the group of your channel), Figure Composer -> preset **BO optimization (main)** (or **BO compact (SI 2x2)** for amp0/vanco) -> Load preset; check **Optimizer shown in BO panels** (maximize) and each panel's channel/metric (the buffer/target panel offers only the metrics that enter the BO objective, so it shows Repeat-scan SNR rather than peak height); render. What it runs on: everything runs locally in the Streamlit app (Python 3.10 virtualenv `.venv310`, CPU only): the line plots and the stack are Matplotlib; the parallel-coordinate and 3D panels are Plotly figures exported to PNG with Kaleido and embedded; nothing leaves your computer.

### 5.4 Landscape figure
BO Session mode, open the sweep session, Channel groups = all, preset **Landscape (3D + traces + 2D slices)**, choose channels 3 and 5, pick best/worst iterations, render.

### 5.5 Before submission
Fill the SI blanks (exploration 0.7, GP falloff 0.2, initial budget 0), resolve the vanco planar/nanoporous conflict, add the surface chemistry, and make the simulation figures with the Simulation tab.

