# BO Paper-Data Audit

Audit date: 2026-10-04  
Last updated: 2026-10-05  
Scope: read-only survey of the reachable Tailscale experiment share, local BO ZIP/extraction, session metadata and experiment logs.

> Cleanup/correction update (2026-10-05): The earlier local `500um_planar_BO_try_again_20260918_112055` extraction and matching ZIP were permanently deleted at the user's request. Subsequent review of the retained session log established that the try-again data and `500um_planar_kana_20260917_170330` are **two distinct kana sessions on different setups**. The required paper set is therefore four folders/archives: two kana, one amp0 and one vancomycin. All known Tailscale endpoints were offline during this correction.

## 1. Storage locations

Reachable share:

`Z: = \\desktop-s31irpl\Users\chienlab355_station2\Documents\Experiment Automation Data`

Capacity:

- Total: 953.20 GB.
- Used: 310.46 GB.
- Free: 642.74 GB.

Other relevant Tailscale archive hosts were offline or unresponsive during the audit:

- `100.94.40.35` / `chienlab-auto1`: offline, last seen five days earlier.
- `desktop-ngl9j66` / `100.70.47.59`: no ping reply.

Logs prove that archives were uploaded to these hosts at specific times even though they could not be inspected now.

## 2. Recommended four paper datasets

### A. Planar kanamycin: station-2 full session

Path:

`Z:\500um_planar_kana_20260917_170330`

Evidence from logs:

- Session started 2026-09-17 and ended 2026-09-28.
- First experiment: `500um_planar_kana_20260917_170349`.
- Initial BO block completed with best Q_run = 4.342.
- An autotitration queue was run; logs show an initial 1,000 µL plain-buffer transfer in four 250 µL strokes and a 6,219-step queue.
- First experiment ended normally on September 21.
- Second experiment: `500um_planar_kana_param_sweep_20260921_111611`.
- Later parameter sweep completed 200 BO iterations.
- Final BO block best Q_run = 11.085.
- Parameter-sweep experiment ended normally on September 28.

Archive evidence:

- A session archive was successfully uploaded on 2026-09-25 to:
  `\\100.94.40.35\Automation Data Drive\young_nephew\500um_planar_kana_20260917_170330.zip`
- That archive host was offline during the audit.

This session is distinct from the setup-5 try-again session below. The remembered approximately 2 GB ZIP is plausible, but its exact archive size and uncompressed total remain unverified because SMB enumeration was too slow and the host is now offline.

### B. Planar kanamycin: setup-5 BO try-again session

Session/archive name:

`500um_planar_BO_try_again_20260918_112055`

Evidence from the retained local session log:

- Session ran on a different workstation path: `C:\Users\chienlab\Documents\Experiment Automation Data (Max and Baris)`.
- Main experiment: `planar_BO_kana_20260918_112056`.
- Separate later experiment: `parameter_sweep_20260921_110003`.
- The main experiment ended at 2026-09-21 10:59:48 and the parameter sweep began at 11:00:03.
- The log contains BO analysis/state paths and parameter-sweep measurements, showing this is a substantive second kana session rather than a duplicate name inside the station-2 session.

Archive evidence:

- Successful uploads were logged to `\\desktop-s31irpl\Users\chienlab355_station2\Documents\Experiment Automation Data\el infanto(setup 5)\500um_planar_BO_try_again_20260918_112055.zip`.
- Earlier successful uploads also used `\\desktop-ngl9j66\Data_Drive\el_infanto(setup_5)\500um_planar_BO_try_again_20260918_112055.zip`.
- The deleted local ZIP was only 704,122,087 bytes and froze an earlier state. It contained 57,604 files / 1.861 GB unpacked but did not establish the size or completeness of the latest remote archive.
- The remembered approximately 2 GB remote ZIP may be the later, more complete archive. Verify its timestamp, entry count and uncompressed size when the setup-5 share reconnects.

This is the second kana folder required for the paper and should be retrieved independently of `500um_planar_kana_20260917_170330`.

### C. Latest successful ampicillin BO

Path:

`Z:\100um_amp0_high_conc_20260915_130213`

Measured size:

- 53,956 files.
- 1,975,824,879 bytes = approximately 1.840 GiB unpacked.
- No ZIP is stored inside the Z: folder.

Evidence from logs:

- Main experiment: `amp0_100um_20260915_130234`.
- Completed 50 BO iterations.
- BO block best Q_run = 6.708.
- A subsequent 5,259-step autotitration/concentration queue ran.
- Logs reached 64,000 µM measurement steps.
- Main experiment ended normally on September 17.
- A short follow-up experiment, `testy_20260917_165927`, also ended normally.

Archive evidence:

- Archive was successfully uploaded repeatedly to:
  `\\desktop-ngl9j66\Data_Drive\young_nephew(setup_3)\100um_amp0_high_conc_20260915_130213.zip`
- The archive host was unresponsive during the audit.
- Estimated ZIP size based on similar datasets: approximately 0.55-0.8 GB.

This is the preferred ampicillin dataset. Two older alternatives scored lower:

- `amp0_100um_20260911_162717`: completed BO, best Q_run = 1.393.
- `amp0_500um_higher_conc_20260914_111605`: completed BO, best Q_run = 2.748; a later measurement stage was stopped by the user.

### D. Vancomycin BO

Path:

`Z:\vanco_first_try_20260826_132944`

Measured size:

- 36,389 files.
- 1.338 GB unpacked.
- 1.338 GB consists principally of 0.812 GB CSV, 0.280 GB JSON optimizer/state files and 0.215 GB PNG plots.
- No ZIP is stored inside the Z: folder.

Evidence from logs:

- Main experiment: `vanco_try_1_20260826_132945`.
- BO block completed.
- Best Q_run = 6.135.
- Autotitration steps are present after optimization.
- Main experiment ended.
- Later `drift_test_20260828_182056` material is included.

Archive evidence:

- After earlier network and permission failures, a session archive was successfully uploaded on 2026-08-28 to:
  `\\desktop-ngl9j66\Data_Drive\young_nephew(setup_3)\vanco_first_try_20260826_132944.zip`
- Estimated ZIP size: approximately 0.4-0.6 GB.

Interpretation caution:

- Earlier measurements were stopped manually during setup/debugging.
- The later BO block completed successfully.
- Because the aptamers may have burned off during autotitration, preserve the complete raw folder and logs, but separate BO optimization evidence from later titration/drift conclusions in the paper.

## 3. Why these four were selected

| Target | Recommended folder | BO result | Titration status | Recommendation |
|---|---|---:|---|---|
| Planar kana, station 2 | `500um_planar_kana_20260917_170330` | 200-iteration sweep, Q 11.085 | Autotitration present | Retrieve as the first kana session |
| Planar kana, setup 5 | `500um_planar_BO_try_again_20260918_112055` | BO data present; historical local snapshot included completed iterations | Parameter sweep began afterward | Retrieve the latest/largest remote archive as the second kana session |
| Ampicillin | `100um_amp0_high_conc_20260915_130213` | 50 iterations, Q 6.708 | Concentration/autotitration completed | Preferred latest amp0 dataset |
| Vancomycin | `vanco_first_try_20260826_132944` | Q 6.135 | Present, but possible aptamer burn-off | Use BO data; treat later titration carefully |

The `ultraflat_kana` folder is not part of this recommendation.

## 4. Local BO copies and redundancy

### Deleted local BO snapshot

- `C:\TEMP\BO\500um_planar_BO_try_again_20260918_112055` and its matching local ZIP were deleted on 2026-10-05.
- Historical extracted size: 1.861 GB across 57,604 files; historical ZIP size: 704,122,087 bytes.
- The deleted pair was verified as exact duplicate representations before deletion.
- Neither represented the latest complete setup-5 try-again session because its later parameter-sweep data continued afterward.
- There is now no complete local copy of the setup-5 session; prioritize retrieving its latest/largest remote archive from `el infanto(setup 5)`.

### OneDrive partial folder

`...\Data\500um_planar_BO_try_again_20260918_112055`

- Only 24 files, 30 MB.
- Those files match archive entries, but 57,580 archive files are missing from this folder.
- Do not treat this folder as the complete dataset.

## 5. Space required for analysis staging

Estimated sizes for the four recommended sessions:

| Dataset | ZIP | Unpacked |
|---|---:|---:|
| Station-2 planar kana | approximately 2 GB, unverified | approximately 5-6 GB, estimated |
| Setup-5 planar BO try-again | approximately 2 GB remembered, unverified; deleted older copy was 0.656 GB | deleted older copy was 1.861 GB; latest remote total unknown, plausibly 5-6 GB |
| Latest amp0 | approximately 0.55-0.8 GB | 1.840 GB measured |
| Vancomycin | approximately 0.4-0.6 GB | 1.338 GB measured |
| Combined | plausibly approximately 5-5.5 GB, unverified | plausibly approximately 13-15 GB |

Keeping all four ZIPs and extracted copies may require approximately 18-21 GB. Do not rely on this estimate until both kana archives can be measured directly.

C: had only 18.2 GB free at the end of the audit, so placing all ZIPs and all extracted trees on C: would leave too little operating-system headroom.

## 6. Short-path recommendation

Do not use `C:\TEMP` as the permanent paper-data location. It is short, but temporary locations may be cleared by applications, scripts or future cleanup.

After freeing at least 20-30 GB, use a short stable structure such as:

```text
C:\bo\kana_station2
C:\bo\kana_try_again
C:\bo\amp
C:\bo\vanco
```

Alternatively:

- Keep the master data on Z:.
- Map a deeper remote archive folder to a drive letter when the archive host returns online.
- Extract one dataset at a time locally.
- Keep the verified ZIP on remote/archive storage and only retain the currently analyzed extraction on C:.

## 7. Retrieval checklist

1. When the setup-5 share returns online, retrieve the newest/largest `500um_planar_BO_try_again_20260918_112055.zip` from `el infanto(setup 5)` (or `el_infanto(setup_5)`).
2. When `chienlab-auto1`/`100.94.40.35` returns online, retrieve and verify `500um_planar_kana_20260917_170330.zip`.
3. When `desktop-ngl9j66` returns online, retrieve:
   - `100um_amp0_high_conc_20260915_130213.zip`
   - `vanco_first_try_20260826_132944.zip`
4. Compare archive entry count and total uncompressed bytes with the live folders before relying on the ZIPs.
5. Preserve `session_log.txt`, `session_metadata.json`, optimizer JSON/pickle state, raw CSV/SWV exports, queue files and method files.
6. For station-2 planar kana, confirm the archive includes both:
   - `500um_planar_kana_20260917_170349`
   - `500um_planar_kana_param_sweep_20260921_111611`
7. For setup-5 try-again, confirm the archive includes both:
   - `planar_BO_kana_20260918_112056`
   - `parameter_sweep_20260921_110003`
8. Confirm the setup-5 archive is newer/larger than the deleted 704,122,087-byte local ZIP and extends beyond the older snapshot's final 2026-09-21 11:25 data.
9. For amp0, confirm the archive includes the full 50-iteration BO and subsequent concentration series.
10. For vancomycin, keep the BO results and drift/titration data distinguishable during analysis.
11. The earlier `C:\TEMP\BO` extraction and matching ZIP have already been deleted. Do not remove any remaining partial or remote kana data until **both** kana archives have been retrieved and independently verified.
